import { useEffect, useState } from 'react';
import { Download, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

const DISMISSED_KEY = 'mediclear_install_dismissed';

export function InstallPrompt() {
  const [installEvent, setInstallEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    // Don't show if already running as standalone PWA
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as Navigator & { standalone?: boolean }).standalone === true;

    if (isStandalone) return;

    // Don't show if user previously dismissed
    const dismissed = localStorage.getItem(DISMISSED_KEY);
    if (dismissed === 'true') return;

    const handler = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e as BeforeInstallPromptEvent);
      setVisible(true);
    };

    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!installEvent) return;
    await installEvent.prompt();
    const { outcome } = await installEvent.userChoice;
    if (outcome === 'accepted') {
      setVisible(false);
      setInstallEvent(null);
    }
  };

  const handleDismiss = () => {
    setVisible(false);
    setInstallEvent(null);
    try {
      localStorage.setItem(DISMISSED_KEY, 'true');
    } catch {
      // ignore
    }
  };

  if (!visible || !installEvent) return null;

  return (
    <div
      className="fixed left-0 right-0 z-50 animate-slide-up-banner"
      style={{ bottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="mx-4 mb-4 bg-card border border-border rounded-2xl shadow-lg p-4 flex items-center gap-3">
        {/* App icon */}
        <div className="shrink-0">
          <img
            src="/assets/generated/app-icon-192.dim_192x192.png"
            alt="MediClear"
            className="w-12 h-12 rounded-xl object-cover"
          />
        </div>

        {/* Text */}
        <div className="flex-1 min-w-0">
          <p className="font-display font-bold text-foreground text-sm leading-tight">
            Install MediClear
          </p>
          <p className="text-muted-foreground text-xs mt-0.5 leading-snug">
            Add to home screen for the best experience
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <Button
            size="sm"
            onClick={handleInstall}
            className="rounded-xl gradient-header border-0 text-primary-foreground font-semibold text-xs h-9 px-3 tap-target"
          >
            <Download className="h-3.5 w-3.5 mr-1" />
            Install
          </Button>
          <button
            onClick={handleDismiss}
            className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors tap-target"
            aria-label="Dismiss install prompt"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
